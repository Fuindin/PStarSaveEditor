PStarSaveEditor

Included are the neccessary files for installing PStarSaveEditor a Phantasy Star, Phantasy Star 2, Phantasy Star 3, and Phantasy Star 4 save state editor.
This application has been tested and runs successfully in Windows 10. It allows editing of save state files with the (.gso, .gsx, .sso, and .ssx) extensions
created from the Fusion364 Genesis/Mega Drive/Sega Master System emulator.

Files included:

PStarSaveEditor.msi
setup.exe

You may install the application by double-clicking the PStarSaveEditor.msi file or double-clicking the setup.exe file.